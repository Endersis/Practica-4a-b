#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
void inicializa_random(long);
double obtiene_siguiente_random(void);
